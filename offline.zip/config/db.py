# config/db.py
from dataclasses import dataclass
import os

@dataclass
class PostgresConfig:
    host: str = os.getenv("PG_HOST", "192.168.101.224")
    port: int = int(os.getenv("PG_PORT", "25432"))
    user: str = os.getenv("PG_USER", "knellbalm")
    password: str = os.getenv("PG_PASSWORD", "dkdldhs8633!@")
    database: str = os.getenv("PG_DB", "da")

    def dsn(self):
        return (
            f"host={self.host} port={self.port} "
            f"user={self.user} password={self.password} dbname={self.database}"
        )
