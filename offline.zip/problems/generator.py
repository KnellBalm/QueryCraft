# problems/generator.py
import json
from pathlib import Path
from datetime import date
from problems.prompt import build_prompt
from engine.postgres_engine import PostgresEngine
from problems.templates import build_expected_sql

PROBLEM_DIR = Path("problems/daily")
PROBLEM_DIR.mkdir(parents=True, exist_ok=True)


def generate(today: date, pg: PostgresEngine) -> str:
    """
    1. Gemini로 문제 생성 (난이도 2/2/2)
    2. expected SQL은 Python 템플릿으로 생성
    3. Postgres에 expected_<problem_id> 테이블 생성
    4. JSON 저장
    """
    # 1. Gemini 호출 (기존 prompt.py 사용)
    problems = build_prompt()

    # problems 예시 구조
    # [
    #   {
    #     "problem_id": "ADV_RET_01",
    #     "difficulty": "advanced",
    #     "topic": "retention",
    #     "question": "...",
    #     "expected_columns": [...],
    #     "sort_keys": [...]
    #   }
    # ]

    for p in problems:
        sql = build_expected_sql(p)

        table_name = f"expected_{p['problem_id']}"
        pg.execute(f"DROP TABLE IF EXISTS {table_name}")
        pg.execute(f"""
            CREATE TABLE {table_name} AS
            {sql}
        """)

    path = PROBLEM_DIR / f"{today}.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(problems, f, ensure_ascii=False, indent=2)

    return str(path)
