# problems/templates.py

def build_expected_sql(problem: dict) -> str:
    """
    문제 타입별로 SQL을 안전하게 생성
    Gemini는 절대 SQL을 만들지 않음
    """
    pid = problem["problem_id"]
    topic = problem["topic"]

    if topic == "retention":
        return """
        WITH base AS (
            SELECT user_id,
                   date_trunc('day', signup_at) AS cohort_date
            FROM users
        ),
        activity AS (
            SELECT
                b.cohort_date,
                date_part('day', e.event_time - b.cohort_date) AS day_n,
                COUNT(DISTINCT e.user_id)::float
                / COUNT(DISTINCT b.user_id) AS retention_rate
            FROM base b
            JOIN events e USING (user_id)
            GROUP BY 1,2
        )
        SELECT *
        FROM activity
        WHERE day_n BETWEEN 0 AND 7
        """

    if topic == "funnel":
        return """
        WITH step1 AS (
            SELECT DISTINCT user_id FROM events WHERE event_name = 'view'
        ),
        step2 AS (
            SELECT DISTINCT user_id FROM events WHERE event_name = 'purchase'
        )
        SELECT
            COUNT(step1.user_id) AS view_users,
            COUNT(step2.user_id) AS purchase_users
        FROM step1
        LEFT JOIN step2 USING (user_id)
        """

    raise ValueError(f"Unknown topic: {topic}")
