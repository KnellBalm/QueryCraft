-- daily session 관리
CREATE TABLE IF NOT EXISTS daily_sessions (
    session_date DATE PRIMARY KEY,
    data_version TEXT,
    problem_set_id TEXT,
    generated_at TIMESTAMP,
    started_at TIMESTAMP,
    finished_at TIMESTAMP,
    status TEXT
);

-- 제출 이력
CREATE TABLE IF NOT EXISTS submissions (
    session_date DATE,
    problem_id TEXT,
    difficulty TEXT,
    submitted_at TIMESTAMP,

    is_correct BOOLEAN,

    error_category TEXT,  -- ENGINE_ERROR | LOGIC_ERROR
    error_type TEXT,
    error_message TEXT
);
