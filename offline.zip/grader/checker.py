# grader/checker.py
import re
import duckdb

class EngineError(Exception):
    def __init__(self, error_type: str, message: str):
        self.error_type = error_type
        self.message = message
        super().__init__(f"{error_type}: {message}")

class LogicError(Exception):
    def __init__(self, error_type: str, message: str):
        self.error_type = error_type
        self.message = message
        super().__init__(f"{error_type}: {message}")

def _map_duckdb_engine_error(msg: str) -> str:
    m = msg.lower()
    if "parser error" in m or "syntax error" in m:
        return "SYNTAX_ERROR"
    if "does not exist" in m and "table" in m:
        return "TABLE_NOT_FOUND"
    if "does not exist" in m and "column" in m:
        return "COLUMN_NOT_FOUND"
    if "binder error" in m and "column" in m:
        return "COLUMN_NOT_FOUND"
    if "conversion error" in m or "cast" in m:
        return "TYPE_MISMATCH"
    if "divide by zero" in m:
        return "DIVIDE_BY_ZERO"
    return "UNKNOWN_ENGINE_ERROR"

def _df_from_query(conn, sql: str):
    try:
        return conn.execute(sql).fetchdf()
    except Exception as e:
        msg = str(e)
        raise EngineError(_map_duckdb_engine_error(msg), msg)

def grade_submission(
    conn,
    user_view: str,
    expected_table: str,
    expected_columns=None,   # list[dict] or list[str] (optional)
    sort_keys=None,          # list[str] (optional)
    float_tol: float = 1e-9,
):
    # 1) 사용자 결과 읽기
    user_df = _df_from_query(conn, f"SELECT * FROM {user_view}")

    # 2) 정답 결과 읽기 (문제 생성 시 생성된 expected_<problem_id> 테이블 사용)
    expected_df = _df_from_query(conn, f"SELECT * FROM {expected_table}")

    # 3) 스키마 검증(선택)
    if expected_columns:
        # expected_columns가 ["colA","colB"] 또는 [{"name":...}, ...] 형태 둘 다 허용
        if isinstance(expected_columns[0], dict):
            exp_cols = [c["name"] for c in expected_columns]
        else:
            exp_cols = list(expected_columns)
        if list(user_df.columns) != exp_cols:
            raise LogicError(
                "SCHEMA_MISMATCH",
                f"컬럼이 다릅니다. expected={exp_cols}, got={list(user_df.columns)}"
            )

    # 4) 행 수
    if len(user_df) != len(expected_df):
        raise LogicError(
            "ROW_COUNT_MISMATCH",
            f"행 수가 다릅니다. expected={len(expected_df)}, got={len(user_df)}"
        )

    # 5) 정렬 규칙(선택): 지정되어 있으면 동일 정렬 후 비교
    if sort_keys:
        missing = [k for k in sort_keys if k not in user_df.columns]
        if missing:
            raise LogicError("SCHEMA_MISMATCH", f"정렬키 컬럼이 없습니다: {missing}")
        user_df = user_df.sort_values(sort_keys).reset_index(drop=True)
        expected_df = expected_df.sort_values(sort_keys).reset_index(drop=True)

    # 6) 값 비교(간단하지만 실용적인 방식)
    # 숫자(float)는 tol 허용, 그 외는 완전 일치
    for i in range(len(user_df)):
        for col in user_df.columns:
            u = user_df.iloc[i][col]
            e = expected_df.iloc[i][col]

            # NaN 처리
            if (u != u) and (e != e):  # both NaN
                continue

            # float 비교
            if isinstance(u, float) or isinstance(e, float):
                try:
                    if abs(float(u) - float(e)) > float_tol:
                        raise LogicError(
                            "VALUE_MISMATCH",
                            f"{i+1}번째 row, {col} 값이 다릅니다. expected={e}, got={u}"
                        )
                except ValueError:
                    if u != e:
                        raise LogicError(
                            "VALUE_MISMATCH",
                            f"{i+1}번째 row, {col} 값이 다릅니다. expected={e}, got={u}"
                        )
            else:
                if u != e:
                    # 흔한 패턴 힌트(중간 강도)
                    hint = ""
                    if "date" in col.lower() or "time" in col.lower():
                        hint = " (날짜/시간 필터 범위를 점검해 보세요)"
                    if "user" in col.lower() and "count" in col.lower():
                        hint = " (중복 제거/집계 기준을 점검해 보세요)"
                    raise LogicError(
                        "VALUE_MISMATCH",
                        f"{i+1}번째 row, {col} 값이 다릅니다. expected={e}, got={u}{hint}"
                    )

    return {"is_correct": True}
