# scripts/run_daily.py
from datetime import date, datetime, timedelta
from engine.postgres_engine import PostgresEngine
from engine.duckdb_engine import DuckDBEngine
from generator.data_generator_advanced import generate as gen_data
from problems.generator import generate as gen_problems
from config import POSTGRES_DSN

def run_daily():
    today = date.today()

    pg = PostgresEngine(POSTGRES_DSN)
    duck = DuckDBEngine("data/pa_lab.duckdb")

    # 1. 전날 SKIPPED 처리
    duck.execute("""
        UPDATE daily_sessions
        SET status='SKIPPED', finished_at=now()
        WHERE session_date = ? AND status IN ('GENERATED','STARTED')
    """, [(today - timedelta(days=1)).isoformat()])

    # 2. 오늘 세션 존재 확인
    if duck.exists("daily_sessions", session_date=today.isoformat()):
        return

    # 3. 데이터 생성 (Postgres)
    gen_data(pg, datetime.now())

    # 4. 문제 + expected 테이블 생성
    problem_path = gen_problems(today, pg)

    # 5. 세션 기록
    duck.execute("""
        INSERT INTO daily_sessions
        (session_date, problem_set_id, generated_at, status)
        VALUES (?, ?, ?, 'GENERATED')
    """, [today.isoformat(), problem_path, datetime.now()])


if __name__ == "__main__":
    run_daily()
