# scripts/submit.py
import argparse
import json
from pathlib import Path
from datetime import date, datetime
import duckdb

from grader.checker import grade_submission, EngineError, LogicError

DEFAULT_DUCKDB_PATH = Path("data/pa_lab.duckdb")
DEFAULT_VIEW_NAME = "my_answer"

PROBLEMS_DIR = Path("problems/daily")  # 권장: problems/daily/YYYY-MM-DD.json

def get_conn_duckdb(db_path: Path):
    return duckdb.connect(str(db_path))

def ensure_session_started(conn, session_date: str):
    row = conn.execute(
        "SELECT started_at, status FROM daily_sessions WHERE session_date = ?",
        [session_date]
    ).fetchone()
    if not row:
        raise RuntimeError(f"daily_sessions에 {session_date} 세션이 없습니다. 먼저 run_daily를 실행하세요.")
    started_at, status = row
    if started_at is None:
        conn.execute(
            "UPDATE daily_sessions SET started_at = ?, status = 'STARTED' WHERE session_date = ?",
            [datetime.now(), session_date]
        )
    elif status == "GENERATED":
        conn.execute(
            "UPDATE daily_sessions SET status = 'STARTED' WHERE session_date = ?",
            [session_date]
        )

def load_problem_set(conn, session_date: str):
    # 1) daily_sessions.problem_set_id에 파일 경로가 들어있다고 가정 (없으면 fallback)
    row = conn.execute(
        "SELECT problem_set_id FROM daily_sessions WHERE session_date = ?",
        [session_date]
    ).fetchone()
    problem_set_id = row[0] if row else None

    candidates = []
    if problem_set_id:
        # problem_set_id가 'problems/daily/2025-01-03.json' 같은 경로일 수 있음
        candidates.append(Path(problem_set_id))
        # 혹시 파일명만 저장했다면:
        candidates.append(PROBLEMS_DIR / f"{problem_set_id}.json")

    # fallback: 표준 경로
    candidates.append(PROBLEMS_DIR / f"{session_date}.json")

    for p in candidates:
        if p.exists():
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f), p

    raise RuntimeError(
        f"문제 세트를 찾지 못했습니다. 다음 경로들을 확인하세요: "
        + ", ".join(str(c) for c in candidates)
    )

def get_next_problem_id(conn, session_date: str, problems: list[dict], explicit_problem_id: str | None):
    if explicit_problem_id:
        return explicit_problem_id

    submitted = conn.execute(
        "SELECT DISTINCT problem_id FROM submissions WHERE session_date = ?",
        [session_date]
    ).fetchall()
    submitted_set = {r[0] for r in submitted}

    for pr in problems:
        pid = pr.get("problem_id")
        if pid and pid not in submitted_set:
            return pid

    # 다 제출했으면 마지막 문제를 다시 제출하도록 유도(override로)
    raise RuntimeError("오늘 문제(6개)가 모두 제출 처리되어 있습니다. --problem 으로 재제출 대상을 지정하세요.")

def insert_submission(conn, session_date: str, problem_id: str, difficulty: str,
                      is_correct: bool, error_category: str | None, error_type: str | None, error_message: str | None):
    conn.execute("""
        INSERT INTO submissions (
            session_date, problem_id, difficulty, submitted_at,
            is_correct, error_category, error_type, error_message
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, [
        session_date, problem_id, difficulty, datetime.now(),
        is_correct, error_category, error_type, error_message
    ])

def update_session_status(conn, session_date: str):
    # 제출이 1개라도 있으면 SUBMITTED
    cnt = conn.execute(
        "SELECT COUNT(*) FROM submissions WHERE session_date = ?",
        [session_date]
    ).fetchone()[0]
    if cnt > 0:
        conn.execute(
            "UPDATE daily_sessions SET status = 'SUBMITTED' WHERE session_date = ?",
            [session_date]
        )

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", help="YYYY-MM-DD (기본: 오늘)")
    parser.add_argument("--db", choices=["duckdb", "postgres"], default="duckdb")
    parser.add_argument("--duckdb-path", default=str(DEFAULT_DUCKDB_PATH))
    parser.add_argument("--view", default=DEFAULT_VIEW_NAME)
    parser.add_argument("--problem", help="problem_id 직접 지정 (기본: 미제출 문제 자동 선택)")
    args = parser.parse_args()

    session_date = args.date or date.today().isoformat()

    if args.db != "duckdb":
        raise NotImplementedError("현재 MVP는 DuckDB만 지원합니다. Postgres는 다음 단계에서 붙입니다.")

    db_path = Path(args.duckdb_path)
    conn = get_conn_duckdb(db_path)

    # 세션 시작 처리
    ensure_session_started(conn, session_date)

    # 문제 세트 로드
    problems_json, problems_path = load_problem_set(conn, session_date)
    # problems_json: [{"problem_id":..., "difficulty":..., "expected_table":...}, ...] 형태 가정
    problems = problems_json if isinstance(problems_json, list) else problems_json.get("problems", [])
    if not problems:
        raise RuntimeError(f"문제 JSON 포맷이 예상과 다릅니다: {problems_path}")

    # 제출 대상 problem_id 결정
    problem_id = get_next_problem_id(conn, session_date, problems, args.problem)

    # 문제 메타 찾기
    problem_meta = next((p for p in problems if p.get("problem_id") == problem_id), None)
    if not problem_meta:
        raise RuntimeError(f"문제 {problem_id} 메타를 문제 세트에서 찾지 못했습니다: {problems_path}")

    difficulty = problem_meta.get("difficulty", "unknown")

    # 채점 수행
    try:
        result = grade_submission(
            conn=conn,
            user_view=args.view,
            expected_table=problem_meta.get("expected_table") or f"expected_{problem_id}",
            expected_columns=problem_meta.get("expected_columns"),   # optional
            sort_keys=problem_meta.get("sort_keys"),                 # optional
        )
        # 정답
        insert_submission(conn, session_date, problem_id, difficulty, True, None, None, None)
        update_session_status(conn, session_date)
        print(f"✅ {problem_id} 정답")
    except EngineError as e:
        insert_submission(conn, session_date, problem_id, difficulty, False, "ENGINE_ERROR", e.error_type, e.message)
        update_session_status(conn, session_date)
        print(f"❌ {problem_id} 실행 오류: {e.error_type} - {e.message}")
    except LogicError as e:
        insert_submission(conn, session_date, problem_id, difficulty, False, "LOGIC_ERROR", e.error_type, e.message)
        update_session_status(conn, session_date)
        print(f"❌ {problem_id} 오답: {e.error_type} - {e.message}")

if __name__ == "__main__":
    main()
