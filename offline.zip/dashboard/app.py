# dashboard/app.py
import duckdb
import pandas as pd
import streamlit as st
from pathlib import Path
import plotly.express as px

DB_PATH = Path("data/pa_lab.duckdb")

@st.cache_data(ttl=10)
def load_tables():
    con = duckdb.connect(str(DB_PATH))
    sessions = con.execute("SELECT * FROM daily_sessions ORDER BY session_date").fetchdf()
    subs = con.execute("SELECT * FROM submissions ORDER BY submitted_at").fetchdf()
    return sessions, subs

st.set_page_config(page_title="Offline PA Lab", layout="wide")
st.title("Offline PA Lab Dashboard")

sessions, subs = load_tables()

col1, col2, col3, col4 = st.columns(4)
col1.metric("세션 수", len(sessions))
col2.metric("제출 수", len(subs))
if len(subs) > 0:
    col3.metric("정답률", f"{(subs['is_correct'].mean()*100):.1f}%")
else:
    col3.metric("정답률", "-")
skipped = (sessions["status"] == "SKIPPED").sum() if len(sessions) else 0
col4.metric("SKIPPED", int(skipped))

st.subheader("최근 30일 트렌드")
if len(sessions):
    s = sessions.copy()
    s["session_date"] = pd.to_datetime(s["session_date"])
    recent = s[s["session_date"] >= (pd.Timestamp.today() - pd.Timedelta(days=30))]
    fig = px.histogram(recent, x="session_date", color="status", barmode="stack")
    st.plotly_chart(fig, use_container_width=True)

st.subheader("난이도별 정답률")
if len(subs):
    by_diff = subs.groupby("difficulty")["is_correct"].mean().reset_index()
    by_diff["acc"] = by_diff["is_correct"] * 100
    fig2 = px.bar(by_diff, x="difficulty", y="acc")
    st.plotly_chart(fig2, use_container_width=True)

st.subheader("에러 분포 (ENGINE vs LOGIC)")
if len(subs):
    err = subs[subs["is_correct"] == False].copy()
    if len(err):
        fig3 = px.histogram(err, x="error_category", color="error_type")
        st.plotly_chart(fig3, use_container_width=True)
    else:
        st.info("오답/에러가 아직 없습니다.")

st.subheader("세션 목록")
st.dataframe(sessions, use_container_width=True)

st.subheader("제출 목록")
st.dataframe(subs, use_container_width=True)
