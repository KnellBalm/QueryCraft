import duckdb
from config import DUCKDB_PATH

class DuckDBEngine:
    def __init__(self):
        self.con = duckdb.connect(DUCKDB_PATH)

    def execute(self, query: str):
        df = self.con.execute(query).fetchdf()
        return {
            "columns": list(df.columns),
            "rows": df.to_dict("records")
        }
