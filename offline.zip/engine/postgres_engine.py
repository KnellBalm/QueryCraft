# engine/postgres_engine.py
import psycopg2

class PostgresEngine:
    def __init__(self, dsn: str):
        self.conn = psycopg2.connect(dsn)
        self.conn.autocommit = True

    def execute(self, sql: str):
        cur = self.conn.cursor()
        cur.execute(sql)

    def fetch_df(self, sql: str):
        import pandas as pd
        return pd.read_sql(sql, self.conn)

    def truncate_practice_tables(self):
        self.execute("""
            TRUNCATE users, sessions, events, orders;
        """)
